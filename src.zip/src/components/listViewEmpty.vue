<template>
  <article class="list--error">
    <div class="">
      <h1>Uh-oh!</h1>
      <p>You look lost on your journey!</p>
      <button class="btn btn-primary">Go back home</button>
    </div>
  </article>
</template>

<script>
export default {};
</script>
